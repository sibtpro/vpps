import customtkinter as ctk
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from gui.auth_screen import AuthScreen
from gui.main_window import MainWindow
from gui.styles import COLORS, WINDOW_SIZE
from utils.session_manager import load_session, has_saved_session

class MSPasswordChangerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("MS Account Password Changer")
        self.geometry(f"{WINDOW_SIZE['width']}x{WINDOW_SIZE['height']}")
        self.configure(fg_color=COLORS["bg_dark"])

        self.center_window()

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.current_screen = None
        self.user_id = None

        if has_saved_session():
            saved_user_id = load_session()
            if saved_user_id:
                print(f"Found saved session for user: {saved_user_id}")
                self.user_id = saved_user_id
                self.show_main_window()
            else:
                self.show_auth_screen()
        else:
            self.show_auth_screen()

    def center_window(self):
        self.update_idletasks()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        x = (screen_width // 2) - (WINDOW_SIZE['width'] // 2)
        y = (screen_height // 2) - (WINDOW_SIZE['height'] // 2)

        self.geometry(f"{WINDOW_SIZE['width']}x{WINDOW_SIZE['height']}+{x}+{y}")

    def show_auth_screen(self):
        if self.current_screen:
            self.current_screen.pack_forget()

        self.current_screen = AuthScreen(self, self.on_auth_success)
        self.current_screen.pack(fill="both", expand=True)

    def on_auth_success(self, user_id):
        self.user_id = user_id
        if self.current_screen:
            self.current_screen.pack_forget()

        self.current_screen = MainWindow(self, user_id)
        self.current_screen.pack(fill="both", expand=True)

    def show_main_window(self):
        if self.current_screen:
            self.current_screen.pack_forget()

        self.current_screen = MainWindow(self, self.user_id)
        self.current_screen.pack(fill="both", expand=True)

def main():
    print("=" * 60)
    print("MS Account Password Changer")
    print("=" * 60)
    print("\nStarting application...")

    app = MSPasswordChangerApp()
    app.mainloop()

if __name__ == "__main__":
    main()
